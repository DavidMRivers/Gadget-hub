This is go9p done in a way that I can understand.

To install:
  export GOPATH=~rminnich/go
  go get -a /k8s.io/minikube/third_party/go9p
  go get -a /k8s.io/minikube/third_party/go9p/ufs
  go install -a /k8s.io/minikube/third_party/go9p/ufs

~/go/bin/ufs


